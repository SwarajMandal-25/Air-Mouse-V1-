#include <Adafruit_TinyUSB.h>  // MUST be first include
#include <bluefruit.h>
#include "LSM6DS3.h"
#include "Wire.h"

// ── IMU ───────────────────────────────────────────────────────────────
LSM6DS3 myIMU(I2C_MODE, 0x6A);

// ── BLE HID ───────────────────────────────────────────────────────────
BLEHidAdafruit blehid;
BLEDis bledis;

// ── USB HID ───────────────────────────────────────────────────────────
Adafruit_USBD_HID usbhid;

// HID Report Descriptor
uint8_t const usbHidDescriptor[] = {
  HID_USAGE_PAGE(HID_USAGE_PAGE_DESKTOP),
  HID_USAGE(HID_USAGE_DESKTOP_MOUSE),
  HID_COLLECTION(HID_COLLECTION_APPLICATION),
    HID_USAGE(HID_USAGE_DESKTOP_POINTER),
    HID_COLLECTION(HID_COLLECTION_PHYSICAL),
      // 3 Buttons
      HID_USAGE_PAGE(HID_USAGE_PAGE_BUTTON),
      HID_USAGE_MIN(1), HID_USAGE_MAX(3),
      HID_LOGICAL_MIN(0), HID_LOGICAL_MAX(1),
      HID_REPORT_COUNT(3), HID_REPORT_SIZE(1),
      HID_INPUT(HID_DATA | HID_VARIABLE | HID_ABSOLUTE),
      // 5-bit padding
      HID_REPORT_COUNT(1), HID_REPORT_SIZE(5),
      HID_INPUT(HID_CONSTANT),
      // X, Y
      HID_USAGE_PAGE(HID_USAGE_PAGE_DESKTOP),
      HID_USAGE(HID_USAGE_DESKTOP_X),
      HID_USAGE(HID_USAGE_DESKTOP_Y),
      HID_LOGICAL_MIN(0x81),
      HID_LOGICAL_MAX(0x7F),
      HID_REPORT_COUNT(2), HID_REPORT_SIZE(8),
      HID_INPUT(HID_DATA | HID_VARIABLE | HID_RELATIVE),
      // Scroll
      HID_USAGE(HID_USAGE_DESKTOP_WHEEL),
      HID_LOGICAL_MIN(0x81),
      HID_LOGICAL_MAX(0x7F),
      HID_REPORT_COUNT(1), HID_REPORT_SIZE(8),
      HID_INPUT(HID_DATA | HID_VARIABLE | HID_RELATIVE),
    HID_COLLECTION_END,
  HID_COLLECTION_END
};

typedef struct __attribute__((packed)) {
  uint8_t buttons;
  int8_t  x;
  int8_t  y;
  int8_t  wheel;
} MouseReport_t;

MouseReport_t usbReport = {0, 0, 0, 0};

#define USB_BTN_LEFT   0x01
#define USB_BTN_RIGHT  0x02
#define USB_BTN_MIDDLE 0x04

// ── Pin Definitions ───────────────────────────────────────────────────
const int LEFT_CLICK_PIN  = D1;
const int RIGHT_CLICK_PIN = D2;
const int ENC_CLK_PIN     = D8;
const int ENC_DT_PIN      = D9;
const int ENC_SW_PIN      = D10;

// RGB LED — raw pin numbers (avoids Seeed macro conflicts)
#define RGB_RED   11
#define RGB_GREEN 13
#define RGB_BLUE  12

// ── Connection Mode ───────────────────────────────────────────────────
enum ConnMode { MODE_NONE, MODE_USB, MODE_BLE };
ConnMode currentMode = MODE_NONE;

// ── Button State ──────────────────────────────────────────────────────
bool lastLeftState  = false;
bool lastRightState = false;
bool lastEncSwState = false;

// ── Encoder State ─────────────────────────────────────────────────────
int    lastEncCLK  = HIGH;
int8_t scrollAccum = 0;

// ── Debounce ──────────────────────────────────────────────────────────
unsigned long lastLeftDebounce  = 0;
unsigned long lastRightDebounce = 0;
unsigned long lastEncSwDebounce = 0;
unsigned long lastEncDebounce   = 0;
const unsigned long DEBOUNCE_MS = 20;

// ── Gyro Calibration ──────────────────────────────────────────────────
float biasGZ = 0;
float biasGY = 0;

// ── Low-pass Filter ───────────────────────────────────────────────────
float smoothVX    = 0;
float smoothVY    = 0;
const float ALPHA    = 0.5f;
const float DEADZONE = 2.0f;

// ─────────────────────────────────────────────────────────────────────
// RGB helpers (active LOW on XIAO nRF52840)
// ─────────────────────────────────────────────────────────────────────
void rgbOff() {
  digitalWrite(RGB_RED,   HIGH);
  digitalWrite(RGB_GREEN, HIGH);
  digitalWrite(RGB_BLUE,  HIGH);
}

void rgbSet(bool r, bool g, bool b) {
  digitalWrite(RGB_RED,   r ? LOW : HIGH);
  digitalWrite(RGB_GREEN, g ? LOW : HIGH);
  digitalWrite(RGB_BLUE,  b ? LOW : HIGH);
}

// ─────────────────────────────────────────────────────────────────────
// Non-blocking LED pattern
// ─────────────────────────────────────────────────────────────────────
void updateLED() {
  unsigned long t;
  switch (currentMode) {
    case MODE_USB:
      t = millis() % 3000;
      if (t < 150 || (t >= 300 && t < 450)) rgbSet(false, true,  false);
      else                                   rgbOff();
      break;
    case MODE_BLE:
      t = millis() % 3000;
      if (t < 150 || (t >= 300 && t < 450)) rgbSet(false, false, true);
      else                                   rgbOff();
      break;
    default:
      t = millis() % 400;
      if (t < 200) rgbSet(true,  false, false);
      else         rgbSet(false, false, true);
      break;
  }
}

// ─────────────────────────────────────────────────────────────────────
// Gyro calibration
// ─────────────────────────────────────────────────────────────────────
void calibrateGyro() {
  Serial.println("Calibrating gyro — keep board still...");
  const int samples = 200;
  float sumGZ = 0, sumGY = 0;

  for (int i = 0; i < samples; i++) {
    if (i % 20 == 0)  rgbSet(true, true, true);
    if (i % 20 == 10) rgbOff();
    sumGZ += myIMU.readFloatGyroZ();
    sumGY += myIMU.readFloatGyroY();
    delay(5);
  }

  biasGZ = sumGZ / samples;
  biasGY = sumGY / samples;
  rgbOff();

  Serial.print("Bias GZ: "); Serial.println(biasGZ);
  Serial.print("Bias GY: "); Serial.println(biasGY);
  Serial.println("Calibration done!");
}

// ─────────────────────────────────────────────────────────────────────
// Encoder
// ─────────────────────────────────────────────────────────────────────
void readEncoder() {
  int clk = digitalRead(ENC_CLK_PIN);
  if (clk == LOW && lastEncCLK == HIGH) {
    unsigned long now = millis();
    if (now - lastEncDebounce >= DEBOUNCE_MS) {
      lastEncDebounce = now;
      scrollAccum += (digitalRead(ENC_DT_PIN) == HIGH) ? 1 : -1;
    }
  }
  lastEncCLK = clk;
}

// ─────────────────────────────────────────────────────────────────────
// Debounced button
// ─────────────────────────────────────────────────────────────────────
bool readButton(int pin, bool &lastState, unsigned long &lastDebounce) {
  bool current = (digitalRead(pin) == LOW);
  if (current != lastState) {
    unsigned long now = millis();
    if (now - lastDebounce >= DEBOUNCE_MS) {
      lastDebounce = now;
      lastState    = current;
      return true;
    }
  }
  return false;
}

// ─────────────────────────────────────────────────────────────────────
// USB mouse helpers
// ─────────────────────────────────────────────────────────────────────
void usbMouseMove(int8_t x, int8_t y) {
  usbReport.x = x; usbReport.y = y; usbReport.wheel = 0;
  usbhid.sendReport(0, &usbReport, sizeof(usbReport));
  usbReport.x = 0; usbReport.y = 0;
}

void usbMouseScroll(int8_t scroll) {
  usbReport.wheel = scroll;
  usbhid.sendReport(0, &usbReport, sizeof(usbReport));
  usbReport.wheel = 0;
}

void usbMouseButtonPress(uint8_t btn) {
  usbReport.buttons |= btn;
  usbhid.sendReport(0, &usbReport, sizeof(usbReport));
}

void usbMouseButtonRelease() {
  usbReport.buttons = 0;
  usbhid.sendReport(0, &usbReport, sizeof(usbReport));
}

// ─────────────────────────────────────────────────────────────────────
// Setup
// ─────────────────────────────────────────────────────────────────────
void setup() {
  // ── RGB pins first so we can show status immediately ─────────────
  pinMode(RGB_RED,   OUTPUT);
  pinMode(RGB_GREEN, OUTPUT);
  pinMode(RGB_BLUE,  OUTPUT);
  rgbOff();

  // ── USB HID MUST be configured before Serial.begin() ─────────────
  TinyUSBDevice.setManufacturerDescriptor("Seeed Studio");
  TinyUSBDevice.setProductDescriptor("XIAO AirMouse");
  usbhid.setReportDescriptor(usbHidDescriptor, sizeof(usbHidDescriptor));
  usbhid.setStringDescriptor("XIAO AirMouse");
  usbhid.begin();

  // Wait up to 2 s for USB host to enumerate the device.
  // If not mounted in time, assume wireless-only boot.
  unsigned long usbWait = millis();
  while (!TinyUSBDevice.mounted() && (millis() - usbWait < 2000)) {
    rgbSet(true, true, false);  // Yellow = waiting for USB enum
    delay(50);
    rgbOff();
    delay(50);
  }

  // ── Serial (after USB init so CDC doesn't fight HID) ─────────────
  Serial.begin(115200);
  unsigned long serialWait = millis();
  while (!Serial && (millis() - serialWait < 2000));

  // ── Input pins ────────────────────────────────────────────────────
  pinMode(LEFT_CLICK_PIN,  INPUT_PULLUP);
  pinMode(RIGHT_CLICK_PIN, INPUT_PULLUP);
  pinMode(ENC_CLK_PIN,     INPUT_PULLUP);
  pinMode(ENC_DT_PIN,      INPUT_PULLUP);
  pinMode(ENC_SW_PIN,      INPUT_PULLUP);
  lastEncCLK = digitalRead(ENC_CLK_PIN);

  // ── IMU ───────────────────────────────────────────────────────────
  if (myIMU.begin() != 0) {
    Serial.println("LSM6DS3 not detected!");
    while (1) { rgbSet(true,false,false); delay(100); rgbOff(); delay(100); }
  }
  Serial.println("LSM6DS3 ready");

  // ── BLE ───────────────────────────────────────────────────────────
  Bluefruit.begin();
  Bluefruit.setTxPower(4);
  Bluefruit.setName("XIAO AirMouse");
  blehid.begin();
  bledis.setManufacturer("Seeed Studio");
  bledis.setModel("XIAO BLE Mouse");
  bledis.begin();
  Bluefruit.Advertising.addFlags(BLE_GAP_ADV_FLAGS_LE_ONLY_GENERAL_DISC_MODE);
  Bluefruit.Advertising.addTxPower();
  Bluefruit.Advertising.addAppearance(BLE_APPEARANCE_HID_MOUSE);
  Bluefruit.Advertising.addService(blehid);
  Bluefruit.ScanResponse.addName();
  Bluefruit.Advertising.start();

  // ── Gyro calibration ─────────────────────────────────────────────
  calibrateGyro();

  Serial.println("Ready. Waiting for USB or BLE connection...");
}

// ─────────────────────────────────────────────────────────────────────
// Loop
// ─────────────────────────────────────────────────────────────────────
void loop() {
  bool usbConnected = TinyUSBDevice.mounted() && usbhid.ready();
  bool bleConnected = Bluefruit.connected();

  // USB has priority
  if      (usbConnected) currentMode = MODE_USB;
  else if (bleConnected) currentMode = MODE_BLE;
  else                   currentMode = MODE_NONE;

  updateLED();

  if (currentMode == MODE_NONE) { delay(10); return; }

  // ── Cursor movement ───────────────────────────────────────────────
  float gz = myIMU.readFloatGyroZ() - biasGZ;
  float gy = myIMU.readFloatGyroY() - biasGY;
  smoothVX = ALPHA * (-gz) + (1.0f - ALPHA) * smoothVX;
  smoothVY = ALPHA * ( gy) + (1.0f - ALPHA) * smoothVY;

  if (abs(smoothVX) > DEADZONE || abs(smoothVY) > DEADZONE) {
    int8_t dx = (int8_t)smoothVX;
    int8_t dy = (int8_t)smoothVY;
    if (currentMode == MODE_USB) usbMouseMove(dx, dy);
    else                         blehid.mouseMove(dx, dy);
  }

  // ── Left click ────────────────────────────────────────────────────
  if (readButton(LEFT_CLICK_PIN, lastLeftState, lastLeftDebounce)) {
    if (lastLeftState) {
      if (currentMode == MODE_USB) usbMouseButtonPress(USB_BTN_LEFT);
      else                         blehid.mouseButtonPress(MOUSE_BUTTON_LEFT);
    } else {
      if (currentMode == MODE_USB) usbMouseButtonRelease();
      else                         blehid.mouseButtonRelease();
    }
  }

  // ── Right click ───────────────────────────────────────────────────
  if (readButton(RIGHT_CLICK_PIN, lastRightState, lastRightDebounce)) {
    if (lastRightState) {
      if (currentMode == MODE_USB) usbMouseButtonPress(USB_BTN_RIGHT);
      else                         blehid.mouseButtonPress(MOUSE_BUTTON_RIGHT);
    } else {
      if (currentMode == MODE_USB) usbMouseButtonRelease();
      else                         blehid.mouseButtonRelease();
    }
  }

  // ── Scroll wheel ──────────────────────────────────────────────────
  readEncoder();
  if (scrollAccum != 0) {
    if (currentMode == MODE_USB) usbMouseScroll(-scrollAccum);
    else                         blehid.mouseScroll(-scrollAccum);
    scrollAccum = 0;
  }

  // ── Middle click ──────────────────────────────────────────────────
  if (readButton(ENC_SW_PIN, lastEncSwState, lastEncSwDebounce)) {
    if (lastEncSwState) {
      if (currentMode == MODE_USB) usbMouseButtonPress(USB_BTN_MIDDLE);
      else                         blehid.mouseButtonPress(MOUSE_BUTTON_MIDDLE);
    } else {
      if (currentMode == MODE_USB) usbMouseButtonRelease();
      else                         blehid.mouseButtonRelease();
    }
  }

  delay(10);
}